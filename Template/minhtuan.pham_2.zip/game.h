#pragma once

void Game_Init(void);

void Game_Update(void);

void Game_Exit(void);